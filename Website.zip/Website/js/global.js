(function(){
  $(document).ready(function() {
      // create header elements
      var header = $('<header>');
      var footer = $ ('<footer>')
      var nav = $('<nav>');
      var menu = $('<ul id="menu">');
      
      // create menu items and append to menu
      var home = $('<li><a href="index.html">Home</a></li>');
      var about = $('<li><a href="about.html">About</a></li>');
      var product = $('<li><a href="product.html">Product</a></li>');
      var contact = $('<li><a href="contact.html">Contact</a></li>');
      // append items to menu
      menu.append(home);
      menu.append(about);
      menu.append(product);
      menu.append(contact);
      
      // append menu to nav, and nav to header
      nav.append(menu);
      header.append(nav);
      footer.append(nav.clone(true));
      // add header to body
      $('body').prepend(header);
      $ ('body').append( footer); 
    });
  })();